package pucrs.s2b.exemplo01;

public interface Hello {
	
	public static void main(String[] args) {
		int a = 20;
		int b = 80;
		int r = somar(a, b);
		if (r == 50)
			
			System.out.println("sucesso");
		
		else
			
			System.out.println("falha");
	}

	public static int somar(int a, int b) {
		int r = a + b;
		return r;
	}
	
}
