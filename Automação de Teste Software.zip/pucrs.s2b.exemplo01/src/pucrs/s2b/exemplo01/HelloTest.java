package pucrs.s2b.exemplo01;

import static org.junit.Assert.*;

import org.junit.Test;

public class HelloTest {

	@Test
	public void testSomar1() {
		int r = Hello.somar(20, 30);
		if (r != 50)
		fail("Not yet implemented");
	}
	
	@Test
	public void testSomar2() {
		int r = Hello.somar(0, 0);
		if (r != 0)
		fail("Not yet implemented");
	}

}
